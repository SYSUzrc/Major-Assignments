﻿namespace database_project
{
    partial class Form_ad_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_ad_password = new System.Windows.Forms.TextBox();
            this.label_ad_password = new System.Windows.Forms.Label();
            this.textBox_ad_no = new System.Windows.Forms.TextBox();
            this.label_ad_no = new System.Windows.Forms.Label();
            this.button_ad_login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox_ad_password
            // 
            this.textBox_ad_password.Location = new System.Drawing.Point(298, 206);
            this.textBox_ad_password.Name = "textBox_ad_password";
            this.textBox_ad_password.Size = new System.Drawing.Size(353, 28);
            this.textBox_ad_password.TabIndex = 7;
            this.textBox_ad_password.TextChanged += new System.EventHandler(this.textBox_user_password_TextChanged);
            // 
            // label_ad_password
            // 
            this.label_ad_password.AutoSize = true;
            this.label_ad_password.Font = new System.Drawing.Font("楷体", 12F);
            this.label_ad_password.Location = new System.Drawing.Point(147, 206);
            this.label_ad_password.Name = "label_ad_password";
            this.label_ad_password.Size = new System.Drawing.Size(142, 24);
            this.label_ad_password.TabIndex = 6;
            this.label_ad_password.Text = "管理员密码:";
            this.label_ad_password.Click += new System.EventHandler(this.label_user_password_Click);
            // 
            // textBox_ad_no
            // 
            this.textBox_ad_no.Location = new System.Drawing.Point(298, 128);
            this.textBox_ad_no.Name = "textBox_ad_no";
            this.textBox_ad_no.Size = new System.Drawing.Size(353, 28);
            this.textBox_ad_no.TabIndex = 5;
            this.textBox_ad_no.TextChanged += new System.EventHandler(this.textBox_user_no_TextChanged);
            // 
            // label_ad_no
            // 
            this.label_ad_no.AutoSize = true;
            this.label_ad_no.Font = new System.Drawing.Font("楷体", 12F);
            this.label_ad_no.Location = new System.Drawing.Point(147, 128);
            this.label_ad_no.Name = "label_ad_no";
            this.label_ad_no.Size = new System.Drawing.Size(142, 24);
            this.label_ad_no.TabIndex = 4;
            this.label_ad_no.Text = "管理员编号:";
            this.label_ad_no.Click += new System.EventHandler(this.label_user_no_Click);
            // 
            // button_ad_login
            // 
            this.button_ad_login.Font = new System.Drawing.Font("楷体", 12F);
            this.button_ad_login.Location = new System.Drawing.Point(326, 316);
            this.button_ad_login.Name = "button_ad_login";
            this.button_ad_login.Size = new System.Drawing.Size(133, 57);
            this.button_ad_login.TabIndex = 8;
            this.button_ad_login.Text = "确定";
            this.button_ad_login.UseVisualStyleBackColor = true;
            this.button_ad_login.Click += new System.EventHandler(this.ad_login_Click);
            // 
            // Form_ad_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_ad_login);
            this.Controls.Add(this.textBox_ad_password);
            this.Controls.Add(this.label_ad_password);
            this.Controls.Add(this.textBox_ad_no);
            this.Controls.Add(this.label_ad_no);
            this.Name = "Form_ad_login";
            this.Text = "管理员登录";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_ad_password;
        private System.Windows.Forms.Label label_ad_password;
        private System.Windows.Forms.TextBox textBox_ad_no;
        private System.Windows.Forms.Label label_ad_no;
        private System.Windows.Forms.Button button_ad_login;
    }
}
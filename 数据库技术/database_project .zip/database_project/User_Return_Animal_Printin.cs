﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Form_ret : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String user_no;

        public Form_ret(string num)
        {
            InitializeComponent();
            user_no = num;
        }

        private void button_ret_ok_Click(object sender, EventArgs e)
        {
            string ani_no = textBox_ani_ret.Text.Trim();
            DataTable dt = QueryAniUse("select ani_record,user_no from Animal_UseRecord where ani_no = '" + ani_no + "' and use_state = 1").Tables["Animal_UseRecord"];
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("输入的编号对应动物不可操作，请检查后重试！");
                textBox_ani_ret.Clear();
                return;
            }
            string record = dt.Rows[0].ItemArray[0].ToString();
            string num = dt.Rows[0].ItemArray[1].ToString();
            if (num == user_no)
            {

                DateTime now = DateTime.Now;
                string nowString = now.ToString();

                //更新动物状态
                string sql = "update Animal_UseRecord set use_state = 0 where ani_record='" + record + "'";
                ExecuteSql(sql);

                //写入归还时间
                sql = "update Animal_UseRecord set ret_date =  '"+ nowString + "' where ani_record='" + record + "'";
                ExecuteSql(sql);

                //更新动物状态
                sql = "update Animal set ani_state = 1 where ani_no='" + ani_no + "'  ";
                ExecuteSql(sql);
                MessageBox.Show("归还成功！");
                textBox_ani_ret.Clear();
                this.Close();
            }
            else
            {
                MessageBox.Show("输入的编号对应动物不可操作，请检查后重试！");
                textBox_ani_ret.Clear();
            }
        }

        public static DataSet QueryAniUse(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal_UseRecord");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

        private void Form_ret_Load(object sender, EventArgs e)
        {

        }
    }
}

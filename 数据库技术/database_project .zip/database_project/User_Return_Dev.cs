﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace database_project
{
    public partial class Form_dev_ret_info : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String user_no;
        private void LoadDeviceUsage()
        {
            this.dev_usage_list.DataSource = QueryDevUse("select dev_no,use_state,use_date,ret_date from Device_UseRecord where user_no ='" + user_no + "'").Tables["Device_UseRecord"];
        }
        public Form_dev_ret_info(string num)
        {
            InitializeComponent();
            user_no = num;
            LoadDeviceUsage(); // 调用LoadDeviceUsage方法初始化数据
        }

        public static DataSet QueryDevUse(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device_UseRecord");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QueryDev(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        private void button_select_Click(object sender, EventArgs e)
        {
            string select_state = textBox_state_info.Text.Trim();
            this.dev_usage_list.DataSource = QueryDevUse("select dev_no,use_state,use_date from Device_UseRecord where user_no ='" + user_no + "' and use_state =" + select_state).Tables["Device_UseRecord"];
        }

        private void label_dev_ret_Click(object sender, EventArgs e)
        {
            Form_dev_ret nextForm = new Form_dev_ret(user_no);
            nextForm.FormClosed += new FormClosedEventHandler(ChildFormClosed); // 订阅子窗口关闭事件
            nextForm.Show();
        }
         //子窗口关闭后更新父窗口
        private void ChildFormClosed(object sender, FormClosedEventArgs e)
        {
            LoadDeviceUsage(); // 子窗口关闭后刷新父窗口
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadDeviceUsage();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Admin_User : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String ad_no;
        public Admin_User(String num, String name)
        {
            InitializeComponent();
            ////更新各类标签
            //更新管理员姓名与账号
            label8.Text =name.ToString();
            label10.Text =num.ToString();
            label6.Text = "null";
            label14.Text = "null";
            ad_no = num;

            Gridview();
        }
        //充值按钮
        private void button_Recharge(object sender, EventArgs e)
        {
            //获得充值账号与数目
            string select_no = textBox1.Text.Trim();
            string amountstring = textBox2.Text.Trim();
            int amount;
            //判断字符串是否为空
            if (string.IsNullOrWhiteSpace(amountstring) || !int.TryParse(amountstring, out amount))
            {
                MessageBox.Show("请输入有效的金额！");
                textBox2.Clear();
                return;
            }
            amount = Convert.ToInt32(amountstring);
            //判断充值账号是否存在与金额是否合理
            string sql;
            DataTable dt1 = QueryUser(sql = "select count(*) from [User] where user_no='" + select_no + "'").Tables["User"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);

            if(count1==0)
            {
                MessageBox.Show("输入的账号不存在，请检查后重试！");
                textBox1.Clear();
                textBox2.Clear();
            }
            else
            {
                sql = "update [User] set user_balance = user_balance +" + amount + " where user_no='" + select_no + "'";
                ExecuteSql(sql);
                //更新视图
                Gridview();
                //更新标签
                dt1 = QueryUser(sql = "select user_balance from [User] where user_no='" + select_no + "'").Tables["User"];
                int select_balance = Convert.ToInt32(dt1.Rows[0][0]);
                label14.Text = select_balance.ToString();
                MessageBox.Show("已成功为该账号充值！");
                //清空金额
                textBox2.Clear();
            }
        }
        private void button_Refund(object sender, EventArgs e)
        {
            //获得退费账号与数目
            string select_no = textBox1.Text.Trim();
            string amountstring = textBox2.Text.Trim();
            int amount;
            //判断字符串是否为空
            if (string.IsNullOrWhiteSpace(amountstring) || !int.TryParse(amountstring, out amount))
            {
                MessageBox.Show("请输入有效的金额！");
                textBox2.Clear();
                return;
            }
            amount = Convert.ToInt32(amountstring);
            //判断退费账号是否存在与金额是否合理
            string sql;
            DataTable dt1 = QueryUser(sql = "select count(*) from [User] where user_no='" + select_no + "'").Tables["User"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            dt1 = QueryUser(sql = "select user_balance from [User] where user_no='" + select_no + "'").Tables["User"];
            int select_balance = Convert.ToInt32(dt1.Rows[0][0]);
           
            if (count1 == 0)
            {
                MessageBox.Show("输入的账号不存在，请检查后重试！");
                textBox1.Clear();
                textBox2.Clear();
            }
            else
            {
              
                if(select_balance<amount)
                {
                    MessageBox.Show("余额不足，请检查后重试！");
                    textBox2.Clear();
                }
                else
                {
                    sql = "update [User] set user_balance = user_balance- " + amount + " where user_no='" + select_no + "'";
                    ExecuteSql(sql);
                    //更新视图
                    Gridview();
                    //更新标签
                    dt1 = QueryUser(sql = "select user_balance from [User] where user_no='" + select_no + "'").Tables["User"];
                    select_balance = Convert.ToInt32(dt1.Rows[0][0]);
                    label14.Text = select_balance.ToString();
                    //清空金额
                    MessageBox.Show("已成功为该账号退费！");
                    textBox2.Clear();
                }

            }
        }
        private void button_Money(object sender, EventArgs e)
        {
            //获得充值账号与数目
            string select_no = textBox1.Text.Trim();
            string amountstring = textBox2.Text.Trim();
 
            //判断充值账号是否存在与金额是否合理
            string sql;
            DataTable dt1 = QueryUser(sql = "select count(*) from [User] where user_no='" + select_no + "'").Tables["User"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            if (count1 == 0)
            {
                MessageBox.Show("输入的账号不存在，请检查后重试！");
                textBox1.Clear();
                textBox2.Clear();
            }
            else
            {
                dt1 = QueryUser(sql = "select user_balance from [User] where user_no='" + select_no + "'").Tables["User"];
                int select_balance = Convert.ToInt32(dt1.Rows[0][0]);
                label14.Text = select_balance.ToString();
            }
        }
        //查询等级
        private void button_level(object sender, EventArgs e)
        {
            //获得充值账号与数目
            string select_no = textBox3.Text.Trim();
  
            //判断修改账号是否存在
            string sql;
            DataTable dt1 = QueryUser(sql = "select count(*) from [User] where user_no='" + select_no + "'").Tables["User"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            if (count1 == 0)
            {
                MessageBox.Show("输入的账号不存在，请检查后重试！");
                textBox3.Clear();
            }
            else
            {
                dt1 = QueryUser(sql = "select user_permission from [User] where user_no='" + select_no + "'").Tables["User"];
                string select_level = dt1.Rows[0][0].ToString();
                label6.Text = select_level;

            }
        }
        //升级按钮
        private void button_levelup(object sender, EventArgs e)
        {
            //获得升级账号
            string select_no = textBox3.Text.Trim();

            //判断升级账号是否存在及其等级
            string sql;
            DataTable dt1 = QueryUser(sql = "select count(*) from [User] where user_no='" + select_no + "'").Tables["User"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);


            if (count1 == 0)
            {
                MessageBox.Show("输入的账号不存在，请检查后重试！");
                textBox3.Clear();
            }
            else
            {
                dt1 = QueryUser(sql = "select user_permission from [User] where user_no='" + select_no + "'").Tables["User"];
                int select_permission = Convert.ToInt32(dt1.Rows[0][0]);
                if (select_permission == 2)
                {
                    MessageBox.Show("已为最高级，请检查后重试！");
                    textBox3.Clear();
                }
                else
                {
                    sql = "update [User] set user_permission = user_permission+ 1 where user_no='" + select_no + "'";
                    ExecuteSql(sql);
                    //更新视图
                    Gridview();
                    MessageBox.Show("已成功为该账号升级！");
                    //更新标签
                    label6.Text = "2";

                }

            }
        }
            //降级标签
            private void button_leveldown(object sender, EventArgs e)
        {
            //获得退费账号与数目
            string select_no = textBox3.Text.Trim();
           
            //判断降级账号是否存在及其等级
            string sql;
            DataTable dt1 = QueryUser(sql = "select count(*) from [User] where user_no='" + select_no + "'").Tables["User"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            if (count1 == 0)
            {
                MessageBox.Show("输入的账号不存在，请检查后重试！");
                textBox1.Clear();
                textBox2.Clear();
            }
            else
            {
                dt1 = QueryUser(sql = "select user_permission from [User] where user_no='" + select_no + "'").Tables["User"];
                int select_permission = Convert.ToInt32(dt1.Rows[0][0]);
                if (select_permission == 1)
                {
                    MessageBox.Show("已为最初级，请检查后重试！");
                    textBox2.Clear();
                }
                else
                {
                    sql = "update [User] set user_permission = user_permission- " + 1 + " where user_no='" + select_no + "'";
                    ExecuteSql(sql);
                    //更新视图
                    Gridview();
                    MessageBox.Show("已成功为该账号降级！");
                        //更新标签
                    label6.Text = "1";
                }

            }
        }
        public static DataSet QueryUser(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "User");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        //初始化窗口
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Gridview();
        }
        private void Gridview()
        {
            // 初始化gridview，查看用户信息
            this.dataGridView1.DataSource = QueryUser("select user_no,user_name,user_balance,user_group,user_permission from [User] ").Tables["User"];
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //执行SQL更新
        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }
    }
}

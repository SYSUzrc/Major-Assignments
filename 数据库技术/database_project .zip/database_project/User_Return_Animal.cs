﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace database_project
{
    public partial class Form_ani_ret_info : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String user_no;
        private void LoadAnimalUsage()
        {
            this.ani_usage_list.DataSource = QueryAniUse("select ani_no,use_state,use_date,ret_date from Animal_UseRecord where user_no ='" + user_no + "'").Tables["Animal_UseRecord"];
        }
        public Form_ani_ret_info(string num)
        {
            InitializeComponent();
            user_no = num;
            LoadAnimalUsage(); // 调用LoadDeviceUsage方法初始化数据
        }

        private void label_ani_aval_Click(object sender, EventArgs e)
        {
            LoadAnimalUsage();
        }

        public static DataSet QueryAniUse(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal_UseRecord");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QueryAni(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        private void button_select_Click(object sender, EventArgs e)
        {
            string select_state = textBox_state_info.Text.Trim();
            this.ani_usage_list.DataSource = QueryAniUse("select ani_no,use_state,use_date from Animal_UseRecord where user_no ='" + user_no + "' and use_state =" + select_state).Tables["Animal_UseRecord"];
        }

        private void label_ani_ret_Click(object sender, EventArgs e)
        {
            Form_ret nextForm = new Form_ret(user_no);
            nextForm.FormClosed += new FormClosedEventHandler(ChildFormClosed); // 订阅子窗口关闭事件
            nextForm.Show();
        }
        private void ChildFormClosed(object sender, FormClosedEventArgs e)
        {
            LoadAnimalUsage(); // 子窗口关闭后刷新父窗口
        }
        //执行SQL更新
        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Form_user_surface : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String user_no;
        string user_balance;
        public Form_user_surface(String num, String name, String bal)
        {
            InitializeComponent();
            label_user_name.Text = name;
            label_bal.Text = bal;
            user_no = num;

        }

        private void label_user_info_Click(object sender, EventArgs e)
        {

        }

        public static DataSet QueryName(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "User");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        private void user_ani_Click(object sender, EventArgs e)
        {
            Form_user_ani nextForm = new Form_user_ani(user_no);
            nextForm.Show();
        }

        private void ani_ret_Click(object sender, EventArgs e)
        {
            Form_ani_ret_info nextForm = new Form_ani_ret_info(user_no);
            nextForm.Show();
        }

        private void user_dev_Click(object sender, EventArgs e)
        {
            Form_user_dev nextForm = new Form_user_dev(user_no);
            nextForm.Show();
        }private void dev_return_Click(object sender, EventArgs e)
        {
            Form_dev_ret_info nextForm = new Form_dev_ret_info(user_no);
            nextForm.Show();
        }

        private void label_user_name_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql;
            DataTable dt1 = QueryUser(sql = "select user_balance from [User] where user_no='" + user_no + "'").Tables["User"];
            int select_balance = Convert.ToInt32(dt1.Rows[0][0]);
            label_bal.Text = select_balance.ToString();
   
        }
        public static DataSet QueryUser(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "User");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }
    }

}

﻿namespace database_project
{
    partial class Form_user_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_user_no = new System.Windows.Forms.Label();
            this.textBox_user_no = new System.Windows.Forms.TextBox();
            this.textBox_user_password = new System.Windows.Forms.TextBox();
            this.label_user_password = new System.Windows.Forms.Label();
            this.button_user_login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_user_no
            // 
            this.label_user_no.AutoSize = true;
            this.label_user_no.Font = new System.Drawing.Font("楷体", 12F);
            this.label_user_no.Location = new System.Drawing.Point(156, 136);
            this.label_user_no.Name = "label_user_no";
            this.label_user_no.Size = new System.Drawing.Size(118, 24);
            this.label_user_no.TabIndex = 0;
            this.label_user_no.Text = "用户编号:";
            // 
            // textBox_user_no
            // 
            this.textBox_user_no.Location = new System.Drawing.Point(280, 136);
            this.textBox_user_no.Name = "textBox_user_no";
            this.textBox_user_no.Size = new System.Drawing.Size(353, 28);
            this.textBox_user_no.TabIndex = 1;
            // 
            // textBox_user_password
            // 
            this.textBox_user_password.Location = new System.Drawing.Point(280, 214);
            this.textBox_user_password.Name = "textBox_user_password";
            this.textBox_user_password.Size = new System.Drawing.Size(353, 28);
            this.textBox_user_password.TabIndex = 3;
            // 
            // label_user_password
            // 
            this.label_user_password.AutoSize = true;
            this.label_user_password.Font = new System.Drawing.Font("楷体", 12F);
            this.label_user_password.Location = new System.Drawing.Point(156, 214);
            this.label_user_password.Name = "label_user_password";
            this.label_user_password.Size = new System.Drawing.Size(118, 24);
            this.label_user_password.TabIndex = 2;
            this.label_user_password.Text = "用户密码:";
            // 
            // button_user_login
            // 
            this.button_user_login.Font = new System.Drawing.Font("楷体", 12F);
            this.button_user_login.Location = new System.Drawing.Point(361, 318);
            this.button_user_login.Name = "button_user_login";
            this.button_user_login.Size = new System.Drawing.Size(93, 42);
            this.button_user_login.TabIndex = 4;
            this.button_user_login.Text = "确定";
            this.button_user_login.UseVisualStyleBackColor = true;
            this.button_user_login.Click += new System.EventHandler(this.user_login_Click);
            // 
            // Form_user_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_user_login);
            this.Controls.Add(this.textBox_user_password);
            this.Controls.Add(this.label_user_password);
            this.Controls.Add(this.textBox_user_no);
            this.Controls.Add(this.label_user_no);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "Form_user_login";
            this.Text = "用户登录";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_user_no;
        private System.Windows.Forms.TextBox textBox_user_no;
        private System.Windows.Forms.TextBox textBox_user_password;
        private System.Windows.Forms.Label label_user_password;
        private System.Windows.Forms.Button button_user_login;
    }
}
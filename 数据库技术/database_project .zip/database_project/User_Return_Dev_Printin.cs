﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Form_dev_ret : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String user_no;

        public Form_dev_ret(string num)
        {
            InitializeComponent();
            user_no = num;
        }

        private void button_ret_ok_Click(object sender, EventArgs e)
        {
            string dev_no = textBox_dev_ret.Text.Trim();
            DataTable dt = QueryDevUse("select dev_record,user_no from Device_UseRecord where dev_no = '" + dev_no + "' and use_state = 1").Tables["Device_UseRecord"];
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("输入的编号对应设备不可操作，请检查后重试！");
                textBox_dev_ret.Clear();
                return;
            }
            string record = dt.Rows[0].ItemArray[0].ToString();
            string num = dt.Rows[0].ItemArray[1].ToString();
            if (num == user_no)
            {
                //更新设备租用表设备状态信息
                string sql = "update Device_UseRecord set use_state = 0 where dev_record='" + record + "'";
                ExecuteSql(sql);

                //写入归还时间
                DateTime now = DateTime.Now;
                string nowString = now.ToString();
                sql = "update Device_UseRecord set ret_date =  '" + nowString + "' where dev_record='" + record + "'";
                ExecuteSql(sql);
                
                //更新设备列表设备状态信息
                sql = "update Device set dev_state = 1 where dev_no='" + dev_no + "'";
                ExecuteSql(sql);

                MessageBox.Show("归还成功！");
                textBox_dev_ret.Clear();
                this.Close();
            }
            else
            {
                MessageBox.Show("输入的编号对应设备不可操作，请检查后重试！");
                textBox_dev_ret.Clear();
            }
        }

        public static DataSet QueryDevUse(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device_UseRecord");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }
    }
}

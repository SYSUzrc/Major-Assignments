﻿namespace database_project
{
    partial class Form_ret
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_ani_ok = new System.Windows.Forms.Button();
            this.textBox_ani_ret = new System.Windows.Forms.TextBox();
            this.label_ani_no = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_ani_ok
            // 
            this.button_ani_ok.Font = new System.Drawing.Font("楷体", 12F);
            this.button_ani_ok.Location = new System.Drawing.Point(146, 113);
            this.button_ani_ok.Name = "button_ani_ok";
            this.button_ani_ok.Size = new System.Drawing.Size(87, 35);
            this.button_ani_ok.TabIndex = 5;
            this.button_ani_ok.Text = "归还";
            this.button_ani_ok.UseVisualStyleBackColor = true;
            this.button_ani_ok.Click += new System.EventHandler(this.button_ret_ok_Click);
            // 
            // textBox_ani_ret
            // 
            this.textBox_ani_ret.Location = new System.Drawing.Point(156, 35);
            this.textBox_ani_ret.Name = "textBox_ani_ret";
            this.textBox_ani_ret.Size = new System.Drawing.Size(200, 28);
            this.textBox_ani_ret.TabIndex = 4;
            // 
            // label_ani_no
            // 
            this.label_ani_no.AutoSize = true;
            this.label_ani_no.Font = new System.Drawing.Font("楷体", 12F);
            this.label_ani_no.Location = new System.Drawing.Point(29, 35);
            this.label_ani_no.Name = "label_ani_no";
            this.label_ani_no.Size = new System.Drawing.Size(130, 24);
            this.label_ani_no.TabIndex = 3;
            this.label_ani_no.Text = "动物编号：";
            // 
            // Form_ret
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 182);
            this.Controls.Add(this.button_ani_ok);
            this.Controls.Add(this.textBox_ani_ret);
            this.Controls.Add(this.label_ani_no);
            this.Name = "Form_ret";
            this.Text = "归还动物";
            this.Load += new System.EventHandler(this.Form_ret_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_ani_ok;
        private System.Windows.Forms.TextBox textBox_ani_ret;
        private System.Windows.Forms.Label label_ani_no;
    }
}
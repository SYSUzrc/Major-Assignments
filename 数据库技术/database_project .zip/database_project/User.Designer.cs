﻿namespace database_project
{
    partial class Form_user_surface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_user_hello = new System.Windows.Forms.Label();
            this.label_user_name = new System.Windows.Forms.Label();
            this.button_user_ani = new System.Windows.Forms.Button();
            this.button_user_dev = new System.Windows.Forms.Button();
            this.button_ani_ret = new System.Windows.Forms.Button();
            this.button_dev_ret = new System.Windows.Forms.Button();
            this.label_bal_info = new System.Windows.Forms.Label();
            this.label_bal = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_user_hello
            // 
            this.label_user_hello.AutoSize = true;
            this.label_user_hello.Font = new System.Drawing.Font("楷体", 12F);
            this.label_user_hello.Location = new System.Drawing.Point(431, 87);
            this.label_user_hello.Name = "label_user_hello";
            this.label_user_hello.Size = new System.Drawing.Size(274, 24);
            this.label_user_hello.TabIndex = 0;
            this.label_user_hello.Text = "欢迎使用实验动物平台！";
            this.label_user_hello.Click += new System.EventHandler(this.label_user_info_Click);
            // 
            // label_user_name
            // 
            this.label_user_name.AutoSize = true;
            this.label_user_name.Font = new System.Drawing.Font("宋体", 12F);
            this.label_user_name.Location = new System.Drawing.Point(174, 87);
            this.label_user_name.Name = "label_user_name";
            this.label_user_name.Size = new System.Drawing.Size(82, 24);
            this.label_user_name.TabIndex = 1;
            this.label_user_name.Text = "label1";
            this.label_user_name.Click += new System.EventHandler(this.label_user_name_Click);
            // 
            // button_user_ani
            // 
            this.button_user_ani.Font = new System.Drawing.Font("楷体", 12F);
            this.button_user_ani.Location = new System.Drawing.Point(160, 259);
            this.button_user_ani.Name = "button_user_ani";
            this.button_user_ani.Size = new System.Drawing.Size(121, 47);
            this.button_user_ani.TabIndex = 2;
            this.button_user_ani.Text = "使用动物";
            this.button_user_ani.UseVisualStyleBackColor = true;
            this.button_user_ani.Click += new System.EventHandler(this.user_ani_Click);
            // 
            // button_user_dev
            // 
            this.button_user_dev.Font = new System.Drawing.Font("楷体", 12F);
            this.button_user_dev.Location = new System.Drawing.Point(513, 259);
            this.button_user_dev.Name = "button_user_dev";
            this.button_user_dev.Size = new System.Drawing.Size(121, 47);
            this.button_user_dev.TabIndex = 3;
            this.button_user_dev.Text = "使用设备";
            this.button_user_dev.UseVisualStyleBackColor = true;
            this.button_user_dev.Click += new System.EventHandler(this.user_dev_Click);
            // 
            // button_ani_ret
            // 
            this.button_ani_ret.Font = new System.Drawing.Font("楷体", 12F);
            this.button_ani_ret.Location = new System.Drawing.Point(160, 358);
            this.button_ani_ret.Name = "button_ani_ret";
            this.button_ani_ret.Size = new System.Drawing.Size(120, 47);
            this.button_ani_ret.TabIndex = 4;
            this.button_ani_ret.Text = "归还动物";
            this.button_ani_ret.UseVisualStyleBackColor = true;
            this.button_ani_ret.Click += new System.EventHandler(this.ani_ret_Click);
            // 
            // button_dev_ret
            // 
            this.button_dev_ret.Font = new System.Drawing.Font("楷体", 12F);
            this.button_dev_ret.Location = new System.Drawing.Point(514, 358);
            this.button_dev_ret.Name = "button_dev_ret";
            this.button_dev_ret.Size = new System.Drawing.Size(120, 47);
            this.button_dev_ret.TabIndex = 5;
            this.button_dev_ret.Text = "归还设备";
            this.button_dev_ret.UseVisualStyleBackColor = true;
            this.button_dev_ret.Click += new System.EventHandler(this.dev_return_Click);
            // 
            // label_bal_info
            // 
            this.label_bal_info.AutoSize = true;
            this.label_bal_info.Font = new System.Drawing.Font("楷体", 12F);
            this.label_bal_info.Location = new System.Drawing.Point(156, 138);
            this.label_bal_info.Name = "label_bal_info";
            this.label_bal_info.Size = new System.Drawing.Size(82, 24);
            this.label_bal_info.TabIndex = 6;
            this.label_bal_info.Text = "余额：";
            // 
            // label_bal
            // 
            this.label_bal.AutoSize = true;
            this.label_bal.Font = new System.Drawing.Font("宋体", 12F);
            this.label_bal.Location = new System.Drawing.Point(225, 138);
            this.label_bal.Name = "label_bal";
            this.label_bal.Size = new System.Drawing.Size(82, 24);
            this.label_bal.TabIndex = 7;
            this.label_bal.Text = "label1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(313, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 48);
            this.button1.TabIndex = 8;
            this.button1.Text = "更新余额";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form_user_surface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label_bal);
            this.Controls.Add(this.label_bal_info);
            this.Controls.Add(this.button_dev_ret);
            this.Controls.Add(this.button_ani_ret);
            this.Controls.Add(this.button_user_dev);
            this.Controls.Add(this.button_user_ani);
            this.Controls.Add(this.label_user_name);
            this.Controls.Add(this.label_user_hello);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.DoubleBuffered = true;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "Form_user_surface";
            this.Text = "用户信息";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_user_hello;
        private System.Windows.Forms.Label label_user_name;
        private System.Windows.Forms.Button button_user_ani;
        private System.Windows.Forms.Button button_user_dev;
        private System.Windows.Forms.Button button_ani_ret;
        private System.Windows.Forms.Button button_dev_ret;
        private System.Windows.Forms.Label label_bal_info;
        private System.Windows.Forms.Label label_bal;
        private System.Windows.Forms.Button button1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class admin_ani : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String ad_no;

        //初始化Gridview视图，初始化其DataSource.
        private void Load_m_ing()
        {
            // 初始化正在维护的动物的列表
            this.m_ing.DataSource = QueryMainten("select ani_no,m_start_t from Animal_Mainten where m_end_t IS NULL").Tables["Animal_Mainten"];
        }

        private void Load_m_todo()
        {
            // 初始化待维护的动物的列表
            this.m_todo.DataSource = QuerytoMainten("select ani_no,ani_class from Animal where NOT EXISTS (SELECT * FROM Animal_Mainten where Animal.ani_no=Animal_mainten.ani_no)").Tables["Animal"];
        }

        public admin_ani(String num, String name)
        {
            InitializeComponent();
            // 查询已维护的数量
            label10.Text = name;
            label12.Text = num;
            DataTable dt1 = QueryMainten("select count(*) from Animal_Mainten where m_end_t IS NOT NULL").Tables["Animal_Mainten"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            label_m_ed.Text = count1.ToString();

            // 查询正在维护的数量
            DataTable dt2 = QueryMainten("select count(*) from Animal_Mainten where m_end_t IS NULL").Tables["Animal_Mainten"];
            int count2 = Convert.ToInt32(dt2.Rows[0][0]);
            label_m_ing.Text = count2.ToString();

            // 查询待维护的数量
            DataTable dt3 = QuerytoMainten("select ani_no, ani_class from Animal where NOT EXISTS (SELECT * FROM Animal_Mainten where Animal.ani_no = Animal_Mainten.ani_no)").Tables["Animal"];
            int count3 = dt3.Rows.Count;
            label_m_todo.Text = count3.ToString();

            ad_no = num;

            
            Load_m_ing(); // 调用LoadDeviceUsage方法初始化数据
            Load_m_todo();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form_ad_surface_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        // 查找待·维护的动物列表
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // 查找正在维护的动物列表
        private void ani_aval_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        { 

        }


        //
        public static DataSet QueryMainten(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal_Mainten");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QuerytoMainten(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //结束维护按钮
        private void button_end_Click(object sender, EventArgs e)
        {
            //时间
            DateTime now = DateTime.Now;
            string nowString = now.ToString();

            string select_no = end_m.Text.Trim();

            //写入归还时间
            string sql = "update Animal_Mainten set m_end_t =  '" + nowString + "' where ani_no='" + select_no + "'";
            ExecuteSql(sql);

            this.m_ing.DataSource = QueryMainten("select ani_no,m_start_t from Animal_Mainten where m_end_t IS NULL").Tables["Animal_Mainten"];
            this.m_todo.DataSource = QuerytoMainten("select ani_no,ani_class from Animal where NOT EXISTS (SELECT * FROM Animal_Mainten where Animal.ani_no=Animal_mainten.ani_no)").Tables["Animal"];

            // 修改已维护的数量
            DataTable dt1 = QueryMainten("select count(*) from Animal_Mainten where m_end_t IS NOT NULL").Tables["Animal_Mainten"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            label_m_ed.Text = count1.ToString();

            // 修改正在维护的数量
            DataTable dt2 = QueryMainten("select count(*) from Animal_Mainten where m_end_t IS NULL").Tables["Animal_Mainten"];
            int count2 = Convert.ToInt32(dt2.Rows[0][0]);
            label_m_ing.Text = count2.ToString();

            // 修改待维护的数量
            DataTable dt3 = QuerytoMainten("select ani_no, ani_class from Animal where NOT EXISTS (SELECT * FROM Animal_Mainten where Animal.ani_no = Animal_Mainten.ani_no)").Tables["Animal"];
            int count3 = dt3.Rows.Count;
            label_m_todo.Text = count3.ToString();

        }
        
        //开始维护按钮
        private void button_start_Click(object sender, EventArgs e)
        {
            //时间
            DateTime now = DateTime.Now;
            string nowString = now.ToString();

            //接收动物序号
            string select_no = m_start_todo.Text.Trim();

            //加入维护表
            string sql = "INSERT INTO Animal_Mainten (ani_no, m_start_t, m_end_t) VALUES ('" + select_no + "', '" + nowString + "', NULL)";
            ExecuteSql(sql);

            this.m_ing.DataSource = QueryMainten("select ani_no,m_start_t from Animal_Mainten where m_end_t IS NULL").Tables["Animal_Mainten"];
            this.m_todo.DataSource = QuerytoMainten("select ani_no,ani_class from Animal where NOT EXISTS (SELECT * FROM Animal_Mainten where Animal.ani_no=Animal_mainten.ani_no)").Tables["Animal"];

            // 修改已维护的数量
            DataTable dt1 = QueryMainten("select count(*) from Animal_Mainten where m_end_t IS NOT NULL").Tables["Animal_Mainten"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            label_m_ed.Text = count1.ToString();

            // 修改正在维护的数量
            DataTable dt2 = QueryMainten("select count(*) from Animal_Mainten where m_end_t IS NULL").Tables["Animal_Mainten"];
            int count2 = Convert.ToInt32(dt2.Rows[0][0]);
            label_m_ing.Text = count2.ToString();

            // 修改待维护的数量
            DataTable dt3 = QuerytoMainten("select ani_no, ani_class from Animal where NOT EXISTS (SELECT * FROM Animal_Mainten where Animal.ani_no = Animal_Mainten.ani_no)").Tables["Animal"];
            int count3 = dt3.Rows.Count;
            label_m_todo.Text = count3.ToString();
        }

        //执行SQL更新
        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

      
    }


}

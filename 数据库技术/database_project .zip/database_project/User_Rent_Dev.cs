﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Form_user_dev : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String user_no;
        int user_permi;
        int user_balance;
        private void LoadDeviceUsage()
        {
            this.dev_aval_list.DataSource = QueryDev("select dev_no,dev_class,dev_cost from Device where dev_state = 1 and dev_permission = " + user_permi).Tables["Device"];
        }
        public Form_user_dev(String num)
        {
            InitializeComponent();

            user_no = num;
            user_permi = int.Parse(QueryUser("select user_permission from [User] where user_no = '" + user_no + "'").Tables["User"].Rows[0].ItemArray[0].ToString());
            user_balance = int.Parse(QueryUser("select user_balance from [User] where user_no = '" + user_no + "'").Tables["User"].Rows[0].ItemArray[0].ToString());
            LoadDeviceUsage(); // 调用LoadDeviceUsage方法初始化数据
            label2.Text = user_balance.ToString();
        }
        
        public static DataSet QueryDev(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QueryUser(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "User");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }
        private void button_back(object sender, EventArgs e)
        {
            LoadDeviceUsage();
        }
        private void button_dev_use_Click(object sender, EventArgs e)
        {
            Form_dev_use nextForm = new Form_dev_use(user_no, user_permi, user_balance);
            nextForm.FormClosed += new FormClosedEventHandler(ChildFormClosed); // 订阅子窗口关闭事件
            nextForm.Show();
        }
        private void ChildFormClosed(object sender, FormClosedEventArgs e)
        {
            LoadDeviceUsage(); // 子窗口关闭后刷新父窗口
            string sql;
            DataTable dt1 = QueryUser(sql = "select user_balance from [User] where user_no='" + user_no + "'").Tables["User"];
            int select_balance = Convert.ToInt32(dt1.Rows[0][0]);
            label2.Text = select_balance.ToString();
        }
        private void button_select_Click(object sender, EventArgs e)
        {
            string select_type = textBox1.Text.Trim();
            this.dev_aval_list.DataSource = QueryDev("select dev_no,dev_class,dev_cost from Device where dev_class ='" + select_type + "' and dev_state = 1 and dev_permission = " + user_permi).Tables["Device"];
        }
    }
}

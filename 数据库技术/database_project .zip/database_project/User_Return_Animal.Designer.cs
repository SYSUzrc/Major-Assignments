﻿namespace database_project
{
    partial class Form_ani_ret_info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_state_info = new System.Windows.Forms.TextBox();
            this.button_select = new System.Windows.Forms.Button();
            this.button_ani_use = new System.Windows.Forms.Button();
            this.label_ani_aval = new System.Windows.Forms.Label();
            this.ani_usage_list = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ani_usage_list)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("楷体", 12F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(19, 419);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "选择使用状态：";
            // 
            // textBox_state_info
            // 
            this.textBox_state_info.Location = new System.Drawing.Point(193, 416);
            this.textBox_state_info.Name = "textBox_state_info";
            this.textBox_state_info.Size = new System.Drawing.Size(138, 35);
            this.textBox_state_info.TabIndex = 10;
            // 
            // button_select
            // 
            this.button_select.Font = new System.Drawing.Font("楷体", 12F);
            this.button_select.Location = new System.Drawing.Point(337, 410);
            this.button_select.Name = "button_select";
            this.button_select.Size = new System.Drawing.Size(88, 41);
            this.button_select.TabIndex = 9;
            this.button_select.Text = "确定";
            this.button_select.UseVisualStyleBackColor = true;
            this.button_select.Click += new System.EventHandler(this.button_select_Click);
            // 
            // button_ani_use
            // 
            this.button_ani_use.Font = new System.Drawing.Font("楷体", 12F);
            this.button_ani_use.Location = new System.Drawing.Point(543, 411);
            this.button_ani_use.Name = "button_ani_use";
            this.button_ani_use.Size = new System.Drawing.Size(135, 41);
            this.button_ani_use.TabIndex = 8;
            this.button_ani_use.Text = "提交归还";
            this.button_ani_use.UseVisualStyleBackColor = true;
            this.button_ani_use.Click += new System.EventHandler(this.label_ani_ret_Click);
            this.button_ani_use.DpiChangedAfterParent += new System.EventHandler(this.label_ani_ret_Click);
            // 
            // label_ani_aval
            // 
            this.label_ani_aval.AutoSize = true;
            this.label_ani_aval.Font = new System.Drawing.Font("楷体", 12F);
            this.label_ani_aval.Location = new System.Drawing.Point(19, 22);
            this.label_ani_aval.Name = "label_ani_aval";
            this.label_ani_aval.Size = new System.Drawing.Size(178, 24);
            this.label_ani_aval.TabIndex = 7;
            this.label_ani_aval.Text = "使用记录列表：";
            this.label_ani_aval.Click += new System.EventHandler(this.label_ani_aval_Click);
            // 
            // ani_usage_list
            // 
            this.ani_usage_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ani_usage_list.Location = new System.Drawing.Point(10, 49);
            this.ani_usage_list.Name = "ani_usage_list";
            this.ani_usage_list.RowHeadersWidth = 62;
            this.ani_usage_list.RowTemplate.Height = 30;
            this.ani_usage_list.Size = new System.Drawing.Size(667, 325);
            this.ani_usage_list.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(431, 410);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 42);
            this.button1.TabIndex = 12;
            this.button1.Text = "还原";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.label_ani_aval_Click);
            // 
            // Form_ani_ret_info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 477);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_state_info);
            this.Controls.Add(this.button_select);
            this.Controls.Add(this.button_ani_use);
            this.Controls.Add(this.label_ani_aval);
            this.Controls.Add(this.ani_usage_list);
            this.Font = new System.Drawing.Font("楷体", 12F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_ani_ret_info";
            this.Text = "动物信息预览";
            ((System.ComponentModel.ISupportInitialize)(this.ani_usage_list)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_state_info;
        private System.Windows.Forms.Button button_select;
        private System.Windows.Forms.Button button_ani_use;
        private System.Windows.Forms.Label label_ani_aval;
        private System.Windows.Forms.DataGridView ani_usage_list;
        private System.Windows.Forms.Button button1;
    }
}
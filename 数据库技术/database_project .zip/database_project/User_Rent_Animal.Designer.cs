﻿namespace database_project
{
    partial class Form_user_ani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ani_aval_list = new System.Windows.Forms.DataGridView();
            this.label_ani_aval = new System.Windows.Forms.Label();
            this.button_ani_use = new System.Windows.Forms.Button();
            this.button_select = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ani_aval_list)).BeginInit();
            this.SuspendLayout();
            // 
            // ani_aval_list
            // 
            this.ani_aval_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ani_aval_list.Location = new System.Drawing.Point(11, 57);
            this.ani_aval_list.Name = "ani_aval_list";
            this.ani_aval_list.RowHeadersWidth = 62;
            this.ani_aval_list.RowTemplate.Height = 30;
            this.ani_aval_list.Size = new System.Drawing.Size(834, 325);
            this.ani_aval_list.TabIndex = 0;
            this.ani_aval_list.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ani_aval_list_CellContentClick);
            // 
            // label_ani_aval
            // 
            this.label_ani_aval.AutoSize = true;
            this.label_ani_aval.Font = new System.Drawing.Font("楷体", 12F);
            this.label_ani_aval.Location = new System.Drawing.Point(21, 30);
            this.label_ani_aval.Name = "label_ani_aval";
            this.label_ani_aval.Size = new System.Drawing.Size(178, 24);
            this.label_ani_aval.TabIndex = 1;
            this.label_ani_aval.Text = "可用动物列表：";
            this.label_ani_aval.Click += new System.EventHandler(this.label_ani_aval_Click);
            // 
            // button_ani_use
            // 
            this.button_ani_use.Font = new System.Drawing.Font("楷体", 12F);
            this.button_ani_use.Location = new System.Drawing.Point(681, 398);
            this.button_ani_use.Name = "button_ani_use";
            this.button_ani_use.Size = new System.Drawing.Size(135, 41);
            this.button_ani_use.TabIndex = 2;
            this.button_ani_use.Text = "提交使用";
            this.button_ani_use.UseVisualStyleBackColor = true;
            this.button_ani_use.Click += new System.EventHandler(this.button_ani_use_Click);
            // 
            // button_select
            // 
            this.button_select.Font = new System.Drawing.Font("楷体", 12F);
            this.button_select.Location = new System.Drawing.Point(388, 398);
            this.button_select.Name = "button_select";
            this.button_select.Size = new System.Drawing.Size(88, 41);
            this.button_select.TabIndex = 3;
            this.button_select.Text = "确定";
            this.button_select.UseVisualStyleBackColor = true;
            this.button_select.Click += new System.EventHandler(this.button_select_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(205, 406);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(149, 28);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("楷体", 12F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(21, 406);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "选择动物种类：";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(506, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 40);
            this.button1.TabIndex = 6;
            this.button1.Text = "还原";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button_back);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(502, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "当前余额为：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(662, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 24);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            // 
            // Form_user_ani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 470);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button_select);
            this.Controls.Add(this.button_ani_use);
            this.Controls.Add(this.label_ani_aval);
            this.Controls.Add(this.ani_aval_list);
            this.Name = "Form_user_ani";
            this.Text = "动物信息预览";
            ((System.ComponentModel.ISupportInitialize)(this.ani_aval_list)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ani_aval_list;
        private System.Windows.Forms.Label label_ani_aval;
        private System.Windows.Forms.Button button_ani_use;
        private System.Windows.Forms.Button button_select;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}
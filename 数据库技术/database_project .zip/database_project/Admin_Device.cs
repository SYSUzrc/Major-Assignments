﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Admin_Device : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        String ad_no;
        public Admin_Device(String num, String name)
        {
            InitializeComponent();
            label12.Text = name;
            label14.Text = num;
            // 修改已维护的数量
            DataTable dt1 = QueryMainten("select count(*) from Device_Mainten where m_end_t IS NOT NULL").Tables["Device_Mainten"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            label2.Text = count1.ToString();

            // 修改正在维护的数量
            DataTable dt2 = QueryMainten("select count(*) from Device_Mainten where m_end_t IS NULL").Tables["Device_Mainten"];
            int count2 = Convert.ToInt32(dt2.Rows[0][0]);
            label4.Text = count2.ToString();

            // 修改待维护的数量
            DataTable dt3 = QuerytoMainten("select dev_no, dev_class from Device where NOT EXISTS (SELECT * FROM Device_Mainten where Device.dev_no = Device_Mainten.dev_no)").Tables["Device"];
            int count3 = dt3.Rows.Count;
            label6.Text = count3.ToString();

            ad_no = num;

            // 调用LoadDeviceUsage方法初始化数据
            Load_m_ing(); 
            Load_m_todo();
        }
        //初始化Gridview视图，初始化其DataSource.
        private void Load_m_ing()
        {
            // 初始化正在维护的设备的列表
            this.dataGridView1.DataSource = QueryMainten("select dev_no,m_start_t from Device_Mainten where m_end_t IS NULL").Tables["Device_Mainten"];
        }
        private void Load_m_todo()
        {
            // 初始化待维护的设备的列表
            this.dataGridView2.DataSource = QuerytoMainten("select dev_no,dev_class from Device where NOT EXISTS (SELECT * FROM Device_Mainten where Device.dev_no=Device_mainten.dev_no)").Tables["Device"];
        }



        //结束维护按钮
        private void button_end_Click(object sender, EventArgs e)
        {
            //时间
            DateTime now = DateTime.Now;
            string nowString = now.ToString();

            string select_no = m_end_list.Text.Trim();

            //写入归还时间
            string sql = "update Device_Mainten set m_end_t =  '" + nowString + "' where dev_no='" + select_no + "'";
            ExecuteSql(sql);

            this.dataGridView1.DataSource = QueryMainten("select dev_no,m_start_t from Device_Mainten where m_end_t IS NULL").Tables["Device_Mainten"];
            this.dataGridView2.DataSource = QuerytoMainten("select dev_no,dev_class from Device where NOT EXISTS (SELECT * FROM Device_Mainten where Device.dev_no=Device_mainten.dev_no)").Tables["Device"];

            // 修改已维护的数量
            DataTable dt1 = QueryMainten("select count(*) from Device_Mainten where m_end_t IS NOT NULL").Tables["Device_Mainten"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            label2.Text = count1.ToString();

            // 修改正在维护的数量
            DataTable dt2 = QueryMainten("select count(*) from Device_Mainten where m_end_t IS NULL").Tables["Device_Mainten"];
            int count2 = Convert.ToInt32(dt2.Rows[0][0]);
            label4.Text = count2.ToString();

            // 修改待维护的数量
            DataTable dt3 = QuerytoMainten("select dev_no, dev_class from Device where NOT EXISTS (SELECT * FROM Device_Mainten where Device.dev_no = Device_Mainten.dev_no)").Tables["Device"];
            int count3 = dt3.Rows.Count;
            label6.Text = count3.ToString();
        }
        //开始维护按钮
        private void button_start_Click(object sender, EventArgs e)
        {
            //时间
            DateTime now = DateTime.Now;
            string nowString = now.ToString();

            //接收设备序号
            string select_no = m_start_list.Text.Trim();

            //加入维护表
            string sql = "INSERT INTO Device_Mainten (dev_no, m_start_t, m_end_t) VALUES ('" + select_no + "', '" + nowString + "', NULL)";
            ExecuteSql(sql);

            this.dataGridView1.DataSource = QueryMainten("select dev_no,m_start_t from Device_Mainten where m_end_t IS NULL").Tables["Device_Mainten"];
            this.dataGridView2.DataSource = QuerytoMainten("select dev_no,dev_class from Device where NOT EXISTS (SELECT * FROM Device_Mainten where Device.dev_no=Device_mainten.dev_no)").Tables["Device"];

            // 修改已维护的数量
            DataTable dt1 = QueryMainten("select count(*) from Device_Mainten where m_end_t IS NOT NULL").Tables["Device_Mainten"];
            int count1 = Convert.ToInt32(dt1.Rows[0][0]);
            label2.Text = count1.ToString();

            // 修改正在维护的数量
            DataTable dt2 = QueryMainten("select count(*) from Device_Mainten where m_end_t IS NULL").Tables["Device_Mainten"];
            int count2 = Convert.ToInt32(dt2.Rows[0][0]);
            label4.Text = count2.ToString();

            // 修改待维护的数量
            DataTable dt3 = QuerytoMainten("select dev_no, dev_class from Device where NOT EXISTS (SELECT * FROM Device_Mainten where Device.dev_no = Device_Mainten.dev_no)").Tables["Device"];
            int count3 = dt3.Rows.Count;
            label6.Text = count3.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        public static DataSet QueryMainten(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device_Mainten");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QuerytoMainten(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }
        //执行SQL更新
        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace database_project
{
    public partial class Form_login : System.Windows.Forms.Form
    {
        public Form_login()
        {
            InitializeComponent();
        }

        private void Form_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void user_login_Click(object sender, EventArgs e)
        {
            Form_user_login nextForm = new Form_user_login();
            nextForm.Show();
        }

        private void ad_login_Click(object sender, EventArgs e)
        {
            Form_ad_login nextForm = new Form_ad_login();
            nextForm.Show();
        }
    }
}

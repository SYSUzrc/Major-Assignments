﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Form_user_login : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        public Form_user_login()
        {
            InitializeComponent();
        }

        public static DataSet Query(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "User");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        private void user_login_Click(object sender, EventArgs e)
        {
            string user_no = textBox_user_no.Text.Trim();
            string user_password = textBox_user_password.Text.Trim();
            DataTable dt = Query("select * from [User] where user_no = '" + user_no + "' and user_password = '" + user_password + "'").Tables["User"];
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("输入的用户编号或用户密码错误，请检查后重试！");
                textBox_user_no.Clear();
                textBox_user_password.Clear();
            }
            else
            {
                Form_user_surface nextForm = new Form_user_surface(user_no, dt.Rows[0].ItemArray[1].ToString(), dt.Rows[0].ItemArray[3].ToString());
                nextForm.Show();
                this.Close();
            }
        }

    }
}

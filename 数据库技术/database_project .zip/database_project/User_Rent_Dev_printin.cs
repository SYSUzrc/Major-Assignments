﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace database_project
{
    public partial class Form_dev_use : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        
        String user_no;
        int user_permi;
        int user_balance;

        public Form_dev_use(String num, int permi, int bal)
        {
            InitializeComponent();
            user_no = num;
            user_permi = permi;
            user_balance = bal;
        }

        private void button_dev_ok_Click(object sender, EventArgs e)
        {
            string dev_no = textBox_dev_use.Text.Trim();
            DataTable dt = QueryDev("select dev_permission,dev_cost,dev_state from Device where dev_no = '" + dev_no + "'").Tables["Device"];
            int dev_permi = int.Parse(dt.Rows[0].ItemArray[0].ToString());
            int dev_cost = int.Parse(dt.Rows[0].ItemArray[1].ToString());
            int dev_state = int.Parse(dt.Rows[0].ItemArray[2].ToString());
            if (dev_state == 0)
            {
                MessageBox.Show("输入的编号对应设备状态不可用，请检查后重试！");
                textBox_dev_use.Clear();
            }
            else if (user_permi < dev_permi)
            {
                MessageBox.Show("输入的编号对应设备权限不支持，请检查后重试！");
                textBox_dev_use.Clear();
            }
            else if (dev_cost > user_balance)
            {
                MessageBox.Show("余额不足，请检查后重试！");
                textBox_dev_use.Clear();
            }
            else
            {
                int record = 0;
                try
                {
                    DataTable r = QueryRecord("select max(dev_record) from Device_use").Tables["Device_use"];
                    record = int.Parse(r.Rows[0].ItemArray[0].ToString()) + 1;
                }
                catch
                    {
                    record = 1;
                }
                //借用时间
                DateTime now = DateTime.Now;
                string nowString = now.ToString();

                string sql = "update Device set dev_state = 0 where dev_no='" + dev_no + "'";
                ExecuteSql(sql);
                sql = "update [User] set user_balance = user_balance -" + dev_cost + "where user_no='" + user_no + "'";
                ExecuteSql(sql);
                sql = "insert into Device_UseRecord values('" + record.ToString() + "','" + user_no + "','" + dev_no + "',1, '" + nowString + "',NULL)";
                //sql = "insert into Device_UseRecord values('" + record.ToString() + "','" + user_no + "','" + dev_no + "',1,null)";
                ExecuteSql(sql);
                MessageBox.Show("使用成功！");
                record++;
                textBox_dev_use.Clear();
                this.Close();
            }
        }

        public static DataSet QueryDev(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QueryRecord(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Device_use");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }



        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }
    }
}

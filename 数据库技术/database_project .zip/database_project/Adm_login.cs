﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_project
{
    public partial class Form_ad_login : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];

        public Form_ad_login()
        {
            InitializeComponent();
        }

        private void label_user_no_Click(object sender, EventArgs e)
        {

        }

        private void label_user_password_Click(object sender, EventArgs e)
        {

        }

        private void textBox_user_no_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_user_password_TextChanged(object sender, EventArgs e)
        {

        }

        public static DataSet Query(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Administrator");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        private void ad_login_Click(object sender, EventArgs e)
        {
            string ad_no = textBox_ad_no.Text.Trim();
            string ad_password = textBox_ad_password.Text.Trim();
            DataTable dt = Query("select * from Administrator where ad_no = '" + ad_no + "' and ad_password = '" + ad_password + "'").Tables["Administrator"];
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("输入的管理员编号或管理员密码错误，请检查后重试！");
                textBox_ad_no.Clear();
                textBox_ad_password.Clear();
            }
            else
            {
                int value = Convert.ToInt32(dt.Rows[0][3]);
                if (value == 1) { 
                    //管理动物
                    admin_ani nextForm = new admin_ani(ad_no, dt.Rows[0].ItemArray[1].ToString());
                    nextForm.Show();
                    this.Close();
                }
                else if(value == 2)
                {
                    ////管理设备
                    Admin_Device nextForm = new Admin_Device(ad_no, dt.Rows[0].ItemArray[1].ToString());
                    nextForm.Show();
                    this.Close();
                }
                else
                {
                    ////管理用户信息
                    Admin_User nextForm = new Admin_User(ad_no, dt.Rows[0].ItemArray[1].ToString());
                    nextForm.Show();
                    this.Close();
                }
            }
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;


namespace database_project
{

    public partial class Form_ani_use : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];


        String user_no;
        int user_permi;
        int user_balance;

        public Form_ani_use(String num, int permi, int bal)
        {
            InitializeComponent();
            user_no = num;
            user_permi = permi;
            user_balance = bal;
        }

        private void button_ani_ok_Click(object sender, EventArgs e)
        {
            
            string ani_no = textBox_ani_use.Text.Trim();
            DataTable dt = QueryAni("select ani_permission,ani_cost,ani_state from Animal where ani_no = '" + ani_no + "'").Tables["Animal"];
            int ani_permi = int.Parse(dt.Rows[0].ItemArray[0].ToString());
            int ani_cost = int.Parse(dt.Rows[0].ItemArray[1].ToString());
            int ani_state = int.Parse(dt.Rows[0].ItemArray[2].ToString());
            if (ani_state == 0)
            {
                MessageBox.Show("输入的编号对应动物状态不可用，请检查后重试！");
                textBox_ani_use.Clear();
            }
            else if (user_permi < ani_permi)
            {
                MessageBox.Show("输入的编号对应动物权限不支持，请检查后重试！");
                textBox_ani_use.Clear();
            }
            else if (ani_cost > user_balance)
            {
                MessageBox.Show("余额不足，请检查后重试！");
                textBox_ani_use.Clear();
            }
            else
            {
                int record = 0;
                try
                {
                    DataTable r = QueryRecord("select max(ani_record) group by from ani_record").Tables["Animal_UseRecord"];
                    record = Convert.ToInt32(r.Rows[0][0]);
                    record += 1;
                }
                catch
                {
                    record = 1;
                }
                //借用时间
                    DateTime now = DateTime.Now;
                    string nowString = now.ToString();
                    //sql = "insert into Animal_UseRecord values('" + record.ToString() + "','" + user_no + "','" + ani_no + "',1,null)";
                    string sql = "update Animal set ani_state = 0 where ani_no='" + ani_no + "'";
                    ExecuteSql(sql);
                    sql = "update [User] set user_balance = user_balance -" + ani_cost + "where user_no='" + user_no + "'";
                    ExecuteSql(sql);
                    sql = "insert into Animal_UseRecord values('" + record.ToString() + "','" + user_no + "','" + ani_no + "',1, '" + nowString + "',NULL)";
                    ExecuteSql(sql);
                    MessageBox.Show("使用成功！");
                    record++;
                    textBox_ani_use.Clear();
                    this.Close();
                   
            }
        }

        public static DataSet QueryAni(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static DataSet QueryRecord(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "Animal_UseRecord");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

        private void Form_ani_use_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace database_project
{
    partial class Form_login
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_login));
            this.button_person_login = new System.Windows.Forms.Button();
            this.button_ad_login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_person_login
            // 
            this.button_person_login.Font = new System.Drawing.Font("楷体", 12F);
            this.button_person_login.Location = new System.Drawing.Point(212, 440);
            this.button_person_login.Name = "button_person_login";
            this.button_person_login.Size = new System.Drawing.Size(193, 63);
            this.button_person_login.TabIndex = 0;
            this.button_person_login.Text = "用户登录";
            this.button_person_login.UseVisualStyleBackColor = true;
            this.button_person_login.Click += new System.EventHandler(this.user_login_Click);
            // 
            // button_ad_login
            // 
            this.button_ad_login.Font = new System.Drawing.Font("楷体", 12F);
            this.button_ad_login.Location = new System.Drawing.Point(582, 440);
            this.button_ad_login.Name = "button_ad_login";
            this.button_ad_login.Size = new System.Drawing.Size(203, 63);
            this.button_ad_login.TabIndex = 2;
            this.button_ad_login.Text = "管理员登录";
            this.button_ad_login.UseVisualStyleBackColor = true;
            this.button_ad_login.Click += new System.EventHandler(this.ad_login_Click);
            // 
            // Form_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(956, 532);
            this.Controls.Add(this.button_ad_login);
            this.Controls.Add(this.button_person_login);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "Form_login";
            this.Text = "登录";
            this.Load += new System.EventHandler(this.Form_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_person_login;
        private System.Windows.Forms.Button button_ad_login;
    }
}


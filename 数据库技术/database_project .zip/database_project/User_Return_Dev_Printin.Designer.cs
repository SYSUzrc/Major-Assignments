﻿namespace database_project
{
    partial class Form_dev_ret
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_dev_ok = new System.Windows.Forms.Button();
            this.textBox_dev_ret = new System.Windows.Forms.TextBox();
            this.label_dev_no = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_dev_ok
            // 
            this.button_dev_ok.Font = new System.Drawing.Font("楷体", 12F);
            this.button_dev_ok.Location = new System.Drawing.Point(146, 113);
            this.button_dev_ok.Name = "button_dev_ok";
            this.button_dev_ok.Size = new System.Drawing.Size(87, 35);
            this.button_dev_ok.TabIndex = 5;
            this.button_dev_ok.Text = "归还";
            this.button_dev_ok.UseVisualStyleBackColor = true;
            this.button_dev_ok.Click += new System.EventHandler(this.button_ret_ok_Click);
            // 
            // textBox_dev_ret
            // 
            this.textBox_dev_ret.Location = new System.Drawing.Point(156, 35);
            this.textBox_dev_ret.Name = "textBox_dev_ret";
            this.textBox_dev_ret.Size = new System.Drawing.Size(200, 28);
            this.textBox_dev_ret.TabIndex = 4;
            // 
            // label_dev_no
            // 
            this.label_dev_no.AutoSize = true;
            this.label_dev_no.Font = new System.Drawing.Font("楷体", 12F);
            this.label_dev_no.Location = new System.Drawing.Point(29, 35);
            this.label_dev_no.Name = "label_dev_no";
            this.label_dev_no.Size = new System.Drawing.Size(130, 24);
            this.label_dev_no.TabIndex = 3;
            this.label_dev_no.Text = "设备编号：";
            // 
            // Form_dev_ret
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 182);
            this.Controls.Add(this.button_dev_ok);
            this.Controls.Add(this.textBox_dev_ret);
            this.Controls.Add(this.label_dev_no);
            this.Name = "Form_dev_ret";
            this.Text = "归还设备";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_dev_ok;
        private System.Windows.Forms.TextBox textBox_dev_ret;
        private System.Windows.Forms.Label label_dev_no;
    }
}